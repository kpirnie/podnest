package backup

import (
	"archive/tar"
	"archive/zip"
	"bufio"
	"bytes"
	"compress/gzip"
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"podnest/internal/db"
	"podnest/internal/logger"
	"podnest/internal/models"
	"podnest/internal/modules"
	"podnest/internal/podman"
)

//go:embed maintenance.html
var maintenanceHTML []byte

const (
	resticBin     = "/usr/bin/restic"
	maintConfName = "000-maint.conf"
	maintHTMLName = "maintenance.html"
)

// Manager orchestrates restic backup and restore operations for all sites
type Manager struct {
	db          *sql.DB
	podman      *podman.Client
	podmanSock  string // socket path for podman CLI exec piping
	appPath     string
	schedulerCh chan string // send cron expression to reschedule; "" disables
	restoring   sync.Map    // map[int64]bool
}

// s3Config holds the S3 connection settings resolved from global settings
type s3Config struct {
	endpoint  string
	bucket    string
	region    string
	accessKey string
	secretKey string
}

// New returns a backup Manager
func New(database *sql.DB, pc *podman.Client, podmanSock, appPath string) *Manager {
	return &Manager{
		db:          database,
		podman:      pc,
		podmanSock:  podmanSock,
		appPath:     appPath,
		schedulerCh: make(chan string, 1),
	}
}

// localRepoPath returns the local restic repo directory for a site
func (m *Manager) localRepoPath(siteName string) string {
	return filepath.Join(m.appPath, "sites", siteName, "backups", "local")
}

// s3RepoURL builds the restic S3 repository URL for a site
func s3RepoURL(endpoint, bucket, siteName string) string {

	// restic S3 format: s3:https://endpoint/bucket/prefix
	ep := strings.TrimRight(endpoint, "/")
	return fmt.Sprintf("s3:%s/%s/%s", ep, bucket, siteName)
}

// loadS3Config reads S3 settings from the database; returns nil if incomplete
func (m *Manager) loadS3Config() (*s3Config, error) {

	// restic S3 backend requires endpoint and bucket at minimum; access key and secret key can be empty for public buckets
	keys := []string{
		"s3_endpoint", "s3_bucket", "s3_region",
		"s3_access_key", "s3_secret_key",
	}

	// read all S3 settings in one batch
	vals := make(map[string]string, len(keys))
	for _, k := range keys {
		v, err := db.GetSetting(m.db, k)
		if err != nil {
			return nil, err
		}
		vals[k] = v
	}

	// endpoint and bucket are the minimum required fields
	if vals["s3_endpoint"] == "" || vals["s3_bucket"] == "" {
		return nil, nil
	}

	// default to us-east-1 if region is not set
	region := vals["s3_region"]
	if region == "" {
		region = "us-east-1"
	}

	// return the config struct
	return &s3Config{
		endpoint:  vals["s3_endpoint"],
		bucket:    vals["s3_bucket"],
		region:    region,
		accessKey: vals["s3_access_key"],
		secretKey: vals["s3_secret_key"],
	}, nil
}

// resticEnv builds the environment slice for a restic command
func resticEnv(password string, s3 *s3Config) []string {
	env := append(os.Environ(), "RESTIC_PASSWORD="+password)
	env = append(env, "TMPDIR=/var/tmp")
	if s3 != nil {
		env = append(env,
			"AWS_ACCESS_KEY_ID="+s3.accessKey,
			"AWS_SECRET_ACCESS_KEY="+s3.secretKey,
			"AWS_DEFAULT_REGION="+s3.region,
		)
	}
	return env
}

// initRepo runs restic init for the given repo, treating an already-initialized
// repo as a non-error
func initRepo(ctx context.Context, repoPath string, env []string) error {

	// restic init will create the repo directory if it doesn't exist
	cmd := exec.CommandContext(ctx, resticBin, "-r", repoPath, "init")
	cmd.Env = env
	out, err := cmd.CombinedOutput()

	// if the repo is already initialized, treat that as a non-error
	if err != nil {
		if strings.Contains(string(out), "already initialized") ||
			strings.Contains(string(out), "config file already exists") {
			return nil
		}
		logger.Error("initRepo: %s: %v — %s", repoPath, err, string(out))
		return fmt.Errorf("restic init: %w — %s", err, string(out))
	}
	logger.Debug("initRepo: initialized repo at %s", repoPath)
	return nil
}

// ensureRepo returns the site's BackupRepo record, creating and persisting one
// (with a fresh random password) if none exists yet
func (m *Manager) ensureRepo(ctx context.Context, site *models.Site) (*models.BackupRepo, error) {

	// check if a repo record already exists for this site
	repo, err := db.GetBackupRepo(m.db, site.ID)
	if err != nil {
		return nil, err
	}
	if repo == nil {

		// generate a cryptographically random password for this site's repos
		b := make([]byte, 32)
		if _, err := rand.Read(b); err != nil {
			logger.Error("ensureRepo: generate password: %v", err)
			return nil, err
		}

		// create a new repo record with the generated password and local path
		repo = &models.BackupRepo{
			SiteID:       site.ID,
			RepoPassword: hex.EncodeToString(b),
			LocalPath:    m.localRepoPath(site.Name),
		}
		if err := db.UpsertBackupRepo(m.db, repo); err != nil {
			return nil, err
		}
		logger.Debug("ensureRepo: created repo record for site %d", site.ID)
	}

	// return the existing or newly created repo record
	return repo, nil
}

// Backup creates a restic snapshot for the given site across all enabled
// destinations. File tree and DB dump are tagged with a shared run ID so they
// can be located together at restore time. Returns the created Backup ID.
func (m *Manager) Backup(ctx context.Context, site *models.Site, label string) (int64, error) {

	// ensure a repo record exists for this site, creating one if needed
	repo, err := m.ensureRepo(ctx, site)
	if err != nil {
		return 0, err
	}

	// load S3 config if S3 backup is enabled
	s3, err := m.loadS3Config()
	if err != nil {
		return 0, err
	}

	// generate a unique tag to correlate the file and DB snapshots for this run
	tagBytes := make([]byte, 8)
	if _, err := rand.Read(tagBytes); err != nil {
		return 0, fmt.Errorf("backup: generate tag: %w", err)
	}
	tag := "podnest-" + hex.EncodeToString(tagBytes)

	// the siteDir is the root for all file operations in this backup
	siteDir := filepath.Join(m.appPath, "sites", site.Name)

	// paths included in the file snapshot
	includePaths := []string{
		filepath.Join(siteDir, "html"),
		filepath.Join(siteDir, "nginx"),
		filepath.Join(siteDir, "php-fpm"),
		filepath.Join(siteDir, "redis"),
		filepath.Join(siteDir, ".env"),
	}

	// paths excluded from the file snapshot
	excludePaths := []string{
		// fastcgi cache — ephemeral, never worth backing up
		filepath.Join(siteDir, "nginx", "cache"),
		// InnoDB binary data dir — replaced entirely by the mysqldump
		filepath.Join(siteDir, "db"),
	}

	// hold the total size of data added across all repos for this backup run
	var totalSize int64
	var backupType int

	// if local backup is enabled, run restic backup for the file tree and DB dump
	if repo.LocalEnabled {
		localEnv := resticEnv(repo.RepoPassword, nil)
		if err := os.MkdirAll(repo.LocalPath, 0750); err != nil {
			return 0, fmt.Errorf("backup: create local repo dir: %w", err)
		}
		logger.Debug("Backup: starting local backup for site %d (%s)", site.ID, site.Name)
		if err := initRepo(ctx, repo.LocalPath, localEnv); err != nil {
			return 0, err
		}
		sz, err := m.backupFiles(ctx, repo.LocalPath, localEnv, includePaths, excludePaths, tag)
		if err != nil {
			return 0, err
		}
		totalSize += sz
		if err := m.backupDB(ctx, site, repo.LocalPath, localEnv, tag, siteDir); err != nil {
			return 0, err
		}
		if err := m.forgetPrune(ctx, repo.LocalPath, localEnv); err != nil {
			logger.Warn("Backup: local forget/prune failed for site %d: %v", site.ID, err)
		}
		backupType = models.BackupTypeLocal
	}

	// if S3 backup is enabled and configured, run restic backup for the file tree and DB dump
	if repo.S3Enabled && s3 != nil {
		s3Repo := s3RepoURL(s3.endpoint, s3.bucket, site.Name)
		s3Env := resticEnv(repo.RepoPassword, s3)
		logger.Debug("Backup: starting S3 backup for site %d (%s)", site.ID, site.Name)
		if err := initRepo(ctx, s3Repo, s3Env); err != nil {
			return 0, err
		}
		sz, err := m.backupFiles(ctx, s3Repo, s3Env, includePaths, excludePaths, tag)
		if err != nil {
			return 0, err
		}
		totalSize += sz
		if err := m.backupDB(ctx, site, s3Repo, s3Env, tag, siteDir); err != nil {
			return 0, err
		}
		if err := m.forgetPrune(ctx, s3Repo, s3Env); err != nil {
			logger.Warn("Backup: S3 forget/prune failed for site %d: %v", site.ID, err)
		}
		if backupType == 0 {
			backupType = models.BackupTypeS3
		}
	}

	// fetch the site's domains to store with the backup record
	siteDomains, err := db.GetDomainsBySite(m.db, site.ID)
	if err != nil {
		logger.Warn("CreateFinalBackup: failed to fetch domains for site %d: %v", site.ID, err)
	}
	var domainList []string
	for _, d := range siteDomains {
		domainList = append(domainList, d.Domain)
	}

	// record the completed backup in the database
	b := &models.Backup{
		SiteID:     site.ID,
		SnapshotID: tag,
		Label:      label,
		BackupType: backupType,
		SizeBytes:  totalSize,
		Domains:    domainList,
	}
	id, err := db.CreateBackup(m.db, b)
	if err != nil {
		return 0, err
	}

	logger.Debug("Backup: completed %s for site %s (id=%d, size=%d)", tag, site.Name, id, totalSize)
	return id, nil
}

// backupFiles runs restic backup for the site's file tree and returns bytes added
func (m *Manager) backupFiles(ctx context.Context, repoPath string, env, paths, excludes []string, tag string) (int64, error) {
	args := []string{"-r", repoPath, "backup", "--json", "--tag", tag}
	for _, ex := range excludes {
		args = append(args, "--exclude", ex)
	}
	args = append(args, paths...)

	cmd := exec.CommandContext(ctx, resticBin, args...)
	cmd.Env = env

	out, err := cmd.Output()
	if err != nil {
		logger.Error("backupFiles: restic backup failed for %s: %v", repoPath, err)
		return 0, fmt.Errorf("restic backup files: %w", err)
	}

	// restic --json outputs one JSON object per line; the last is the summary
	var summary struct {
		DataAdded int64 `json:"data_added"`
	}
	lines := bytes.Split(bytes.TrimSpace(out), []byte("\n"))
	if len(lines) > 0 {
		_ = json.Unmarshal(lines[len(lines)-1], &summary)
	}

	logger.Debug("backupFiles: %d bytes added to %s", summary.DataAdded, repoPath)
	return summary.DataAdded, nil
}

// backupDB pipes mysqldump from the MariaDB container directly into
// restic backup --stdin, storing it as db_dump.sql in the snapshot
func (m *Manager) backupDB(ctx context.Context, site *models.Site, repoPath string, env []string, tag, siteDir string) error {

	// only sites with a MariaDB container need a DB backup
	if !modules.TypeModule(site.SiteType).HasDatabase() {
		logger.Debug("backupDB: skipping non-PHP site %s", site.Name)
		return nil
	}

	// read DB credentials from the site's .env file
	dbName, err := readEnvValue(filepath.Join(siteDir, ".env"), "DB_NAME")
	if err != nil {
		return fmt.Errorf("backupDB: DB_NAME: %w", err)
	}
	rootPass, err := readEnvValue(filepath.Join(siteDir, ".env"), "DB_ROOT_PASS")
	if err != nil {
		return fmt.Errorf("backupDB: DB_ROOT_PASS: %w", err)
	}

	// set up restic to receive the dump on stdin
	resticCmd := exec.CommandContext(ctx, resticBin,
		"-r", repoPath, "backup",
		"--stdin", "--stdin-filename", "db_dump.sql",
		"--tag", tag,
	)
	resticCmd.Env = env

	// capture restic stderr for error reporting
	var resticStderr bytes.Buffer
	resticCmd.Stderr = &resticStderr

	// stream mysqldump from the MariaDB container via podman exec CLI;
	// CONTAINER_HOST points the CLI at the correct socket
	dbContainer := podman.ContainerName(site.Name, "db")
	dumpCmd := exec.CommandContext(ctx, "podman",
		"exec", "--user=mysql", dbContainer,
		"sh", "-c",
		fmt.Sprintf(
			"mysqldump -uroot -p%s --single-transaction --quick --routines %s 2>/dev/null || "+
				"mariadb-dump -uroot -p%s --single-transaction --quick --routines %s",
			rootPass, dbName, rootPass, dbName,
		),
	)
	dumpCmd.Env = append(os.Environ(), "CONTAINER_HOST=unix://"+m.podmanSock)

	// capture dump stderr for error reporting
	var dumpStderr bytes.Buffer
	dumpCmd.Stderr = &dumpStderr

	// connect: dumpCmd.Stdout → resticCmd.Stdin
	resticCmd.Stdin, err = dumpCmd.StdoutPipe()
	if err != nil {
		return fmt.Errorf("backupDB: stdout pipe: %w", err)
	}

	logger.Debug("backupDB: starting DB stream to restic for site %s", site.Name)

	if err := dumpCmd.Start(); err != nil {
		return fmt.Errorf("backupDB: start mysqldump: %w", err)
	}
	if err := resticCmd.Run(); err != nil {
		dumpCmd.Wait()
		return fmt.Errorf("backupDB: restic: %w — restic_stderr: %s — dump_stderr: %s",
			err, resticStderr.String(), dumpStderr.String())
	}
	if err := dumpCmd.Wait(); err != nil {
		return fmt.Errorf("backupDB: mysqldump wait: %w — dump_stderr: %s",
			err, dumpStderr.String())
	}

	logger.Debug("backupDB: DB snapshot complete for site %s", site.Name)
	return nil
}

// -- restore -----------------------------------------------------------------

// Restore restores a site from the snapshot identified by the given Backup
// record. Nginx serves the maintenance page for the duration.
func (m *Manager) Restore(ctx context.Context, site *models.Site, backup *models.Backup) error {

	m.restoring.Store(site.ID, true)
	defer m.restoring.Delete(site.ID)

	repo, err := db.GetBackupRepo(m.db, site.ID)
	if err != nil || repo == nil {
		return fmt.Errorf("restore: no repo configured for site %s", site.Name)
	}

	s3, err := m.loadS3Config()
	if err != nil {
		return err
	}

	// resolve which repo to restore from based on the backup type
	var repoPath string
	var env []string
	switch backup.BackupType {
	case models.BackupTypeLocal:
		repoPath = repo.LocalPath
		env = resticEnv(repo.RepoPassword, nil)
	case models.BackupTypeS3:
		if s3 == nil {
			return fmt.Errorf("restore: S3 not configured")
		}
		repoPath = s3RepoURL(s3.endpoint, s3.bucket, site.Name)
		env = resticEnv(repo.RepoPassword, s3)
	default:
		return fmt.Errorf("restore: unknown backup type %d", backup.BackupType)
	}

	siteDir := filepath.Join(m.appPath, "sites", site.Name)

	// enable maintenance mode before touching any site data
	if err := m.enableMaintenance(ctx, site, siteDir); err != nil {
		return fmt.Errorf("restore: enable maintenance: %w", err)
	}

	// always lift maintenance mode on exit, even on error
	defer func() {
		if err := m.disableMaintenance(ctx, site, siteDir); err != nil {
			logger.Error("Restore: disable maintenance for site %s: %v", site.Name, err)
		}
	}()

	// restore the files
	if err := m.restoreFiles(ctx, repoPath, env, backup.SnapshotID, siteDir); err != nil {
		return fmt.Errorf("restore files: %w", err)
	}

	// reapply correct ownership — restic restores files as root
	m.fixPostRestorePerms(siteDir, site.ID)

	// restore the database
	if err := m.restoreDB(ctx, site, repoPath, env, backup.SnapshotID, siteDir); err != nil {
		return fmt.Errorf("restore db: %w", err)
	}

	logger.Debug("Restore: completed for site %s from tag %s", site.Name, backup.SnapshotID)
	return nil
}

// add exported method
func (m *Manager) IsRestoring(siteID int64) bool {
	_, ok := m.restoring.Load(siteID)
	return ok
}

// restoreFiles runs restic restore for the file tree snapshot matching the tag
func (m *Manager) restoreFiles(ctx context.Context, repoPath string, env []string, tag, siteDir string) error {
	snapID, err := m.findSnapshot(ctx, repoPath, env, tag, "files")
	if err != nil {
		return err
	}

	args := []string{
		"-r", repoPath, "restore", snapID,
		"--target", "/",
		// exclude the nginx cache and the maintenance conf we injected
		"--exclude", filepath.Join(siteDir, "nginx", "cache"),
		"--exclude", filepath.Join(siteDir, "nginx", "conf.d", maintConfName),
	}
	cmd := exec.CommandContext(ctx, resticBin, args...)
	cmd.Env = env

	if out, err := cmd.CombinedOutput(); err != nil {
		logger.Error("restoreFiles: restic restore: %v — %s", err, string(out))
		return fmt.Errorf("restic restore: %w — %s", err, string(out))
	}

	logger.Debug("restoreFiles: restored files from snapshot %s", snapID)
	return nil
}

// restoreDB streams the DB dump out of restic and pipes it into mysql inside
// the MariaDB container via the podman exec CLI
func (m *Manager) restoreDB(ctx context.Context, site *models.Site, repoPath string, env []string, tag, siteDir string) error {
	if site.SiteType != models.SiteTypeWordPress && site.SiteType != models.SiteTypePHP {
		return nil
	}

	snapID, err := m.findSnapshot(ctx, repoPath, env, tag, "db")
	if err != nil {
		return err
	}

	rootPass, err := readEnvValue(filepath.Join(siteDir, ".env"), "DB_ROOT_PASS")
	if err != nil {
		return fmt.Errorf("restoreDB: DB_ROOT_PASS: %w", err)
	}
	dbName, err := readEnvValue(filepath.Join(siteDir, ".env"), "DB_NAME")
	if err != nil {
		return fmt.Errorf("restoreDB: DB_NAME: %w", err)
	}

	// dump the SQL from restic into a temp file on the host
	tmp, err := os.CreateTemp("", "podnest-restore-*.sql")
	if err != nil {
		return fmt.Errorf("restoreDB: create temp: %w", err)
	}
	defer os.Remove(tmp.Name())

	dumpCmd := exec.CommandContext(ctx, resticBin, "-r", repoPath, "dump", snapID, "db_dump.sql")
	dumpCmd.Env = env
	dumpCmd.Stdout = tmp
	if err := dumpCmd.Run(); err != nil {
		tmp.Close()
		return fmt.Errorf("restoreDB: restic dump: %w", err)
	}
	tmp.Close()

	// copy the SQL file into the container
	dbContainer := podman.ContainerName(site.Name, "db")
	cpCmd := exec.CommandContext(ctx, "podman",
		"cp", tmp.Name(), dbContainer+":/tmp/podnest-restore.sql",
	)
	cpCmd.Env = append(os.Environ(), "CONTAINER_HOST=unix://"+m.podmanSock)
	if out, err := cpCmd.CombinedOutput(); err != nil {
		return fmt.Errorf("restoreDB: podman cp: %w — %s", err, string(out))
	}

	// run mysql inside the container redirected from the copied file
	mysqlCmd := exec.CommandContext(ctx, "podman",
		"exec", dbContainer,
		"sh", "-c",
		fmt.Sprintf("mariadb -uroot -p%s %s < /tmp/podnest-restore.sql && rm /tmp/podnest-restore.sql", rootPass, dbName),
	)
	mysqlCmd.Env = append(os.Environ(), "CONTAINER_HOST=unix://"+m.podmanSock)
	var mysqlStderr bytes.Buffer
	mysqlCmd.Stderr = &mysqlStderr
	if err := mysqlCmd.Run(); err != nil {
		return fmt.Errorf("restoreDB: mariadb: %w — %s", err, mysqlStderr.String())
	}

	logger.Debug("restoreDB: DB restored for site %s from snapshot %s", site.Name, snapID)
	return nil
}

// findSnapshot queries the restic repo for the snapshot matching the tag and
// kind ("files" or "db"). The DB snapshot is identified by having a single
// path entry of "db_dump.sql"; the file snapshot has directory paths.
func (m *Manager) findSnapshot(ctx context.Context, repoPath string, env []string, tag, kind string) (string, error) {
	// list ALL snapshots — tag filtering via restic CLI can miss stdin snapshots
	cmd := exec.CommandContext(ctx, resticBin,
		"-r", repoPath, "snapshots", "--json",
	)
	cmd.Env = env

	out, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("findSnapshot: restic snapshots: %w", err)
	}

	var snaps []struct {
		ID    string   `json:"id"`
		Tags  []string `json:"tags"`
		Paths []string `json:"paths"`
	}
	if err := json.Unmarshal(out, &snaps); err != nil {
		return "", fmt.Errorf("findSnapshot: parse: %w", err)
	}

	for _, s := range snaps {
		// check tag matches manually
		hasTag := false
		for _, t := range s.Tags {
			if t == tag {
				hasTag = true
				break
			}
		}
		if !hasTag {
			continue
		}

		logger.Debug("findSnapshot: candidate %s tags=%v paths=%v", s.ID, s.Tags, s.Paths)

		isDB := len(s.Paths) == 1 &&
			(s.Paths[0] == "db_dump.sql" || s.Paths[0] == "/db_dump.sql")
		if kind == "db" && isDB {
			return s.ID, nil
		}
		if kind == "files" && !isDB {
			return s.ID, nil
		}
	}

	return "", fmt.Errorf("findSnapshot: no %s snapshot for tag %s", kind, tag)
}

// -- forget / prune ----------------------------------------------------------

// forgetPrune applies the configured retention policy and prunes unreachable data
func (m *Manager) forgetPrune(ctx context.Context, repoPath string, env []string) error {
	// clear any stale locks before pruning
	unlockCmd := exec.CommandContext(ctx, resticBin, "-r", repoPath, "unlock")
	unlockCmd.Env = env
	_ = unlockCmd.Run()

	retainDays, err := db.GetSetting(m.db, "backup_retain_days")
	if err != nil || retainDays == "" {
		retainDays = "30"
	}

	cmd := exec.CommandContext(ctx, resticBin,
		"-r", repoPath, "forget",
		"--keep-within", retainDays+"d",
		"--prune",
	)
	cmd.Env = env

	if out, err := cmd.CombinedOutput(); err != nil {
		logger.Error("forgetPrune: %s: %v — %s", repoPath, err, string(out))
		return fmt.Errorf("restic forget: %w", err)
	}

	logger.Debug("forgetPrune: pruned %s with %sd retention", repoPath, retainDays)
	return nil
}

// -- maintenance mode --------------------------------------------------------

// enableMaintenance writes the maintenance page and injects a catch-all nginx
// config that returns 503 for all requests
func (m *Manager) enableMaintenance(ctx context.Context, site *models.Site, siteDir string) error {
	// write the maintenance page into the site's web root
	htmlPath := filepath.Join(siteDir, "html", maintHTMLName)
	if err := os.WriteFile(htmlPath, maintenanceHTML, 0644); err != nil {
		return fmt.Errorf("write maintenance.html: %w", err)
	}

	// 000- prefix ensures this conf sorts first and takes priority
	maintConf := `server {
    listen 80 default_server;
    root /var/www/html;
    error_page 503 /maintenance.html;
    location = /maintenance.html { internal; }
    location / { return 503; }
}
`
	confPath := filepath.Join(siteDir, "nginx", "conf.d", maintConfName)
	if err := os.WriteFile(confPath, []byte(maintConf), 0644); err != nil {
		return fmt.Errorf("write maintenance nginx conf: %w", err)
	}

	if err := m.nginxReload(ctx, site.Name); err != nil {
		return fmt.Errorf("nginx reload (maintenance on): %w", err)
	}

	logger.Debug("enableMaintenance: maintenance mode on for site %s", site.Name)
	return nil
}

// disableMaintenance removes the maintenance conf and page, then reloads nginx
func (m *Manager) disableMaintenance(ctx context.Context, site *models.Site, siteDir string) error {
	confPath := filepath.Join(siteDir, "nginx", "conf.d", maintConfName)
	if err := os.Remove(confPath); err != nil && !os.IsNotExist(err) {
		logger.Warn("disableMaintenance: remove conf: %v", err)
	}

	htmlPath := filepath.Join(siteDir, "html", maintHTMLName)
	if err := os.Remove(htmlPath); err != nil && !os.IsNotExist(err) {
		logger.Warn("disableMaintenance: remove html: %v", err)
	}

	if err := m.nginxReload(ctx, site.Name); err != nil {
		return fmt.Errorf("nginx reload (maintenance off): %w", err)
	}

	logger.Debug("disableMaintenance: maintenance mode off for site %s", site.Name)
	return nil
}

// nginxReload sends nginx -s reload inside the site's nginx container
func (m *Manager) nginxReload(ctx context.Context, siteName string) error {
	containerName := podman.ContainerName(siteName, "nginx")

	var execResp struct {
		ID string `json:"Id"`
	}
	spec := map[string]any{
		"AttachStdout": false,
		"AttachStderr": false,
		"Detach":       true,
		"Cmd":          []string{"nginx", "-s", "reload"},
	}
	if err := m.podman.PostJSON(ctx,
		"/v4.0.0/libpod/containers/"+containerName+"/exec",
		spec, &execResp,
	); err != nil {
		return fmt.Errorf("nginxReload: create exec: %w", err)
	}
	if err := m.podman.PostJSON(ctx,
		"/v4.0.0/libpod/exec/"+execResp.ID+"/start",
		map[string]any{"Detach": true}, nil,
	); err != nil {
		return fmt.Errorf("nginxReload: start exec: %w", err)
	}

	logger.Debug("nginxReload: sent reload to %s", containerName)
	return nil
}

// -- scheduler ---------------------------------------------------------------

// StartScheduler launches the background cron scheduler goroutine.
// It reads backup_schedule from settings on startup and whenever Reschedule
// is called.
func (m *Manager) StartScheduler(ctx context.Context) {
	go m.runScheduler(ctx)
}

// Reschedule signals the scheduler to re-arm with a new cron expression.
// Sending an empty string disables scheduled backups.
func (m *Manager) Reschedule(expr string) {
	// non-blocking send; if the channel is already full the pending value
	// is the latest so the signal can be safely dropped
	select {
	case m.schedulerCh <- expr:
	default:
	}
}

// runScheduler is the main scheduler loop
func (m *Manager) runScheduler(ctx context.Context) {
	var timer *time.Timer
	var timerCh <-chan time.Time

	// arm or disarm the timer from a cron expression
	arm := func(expr string) {
		if timer != nil {
			timer.Stop()
			timer = nil
			timerCh = nil
		}
		if expr == "" {
			logger.Debug("scheduler: disabled")
			return
		}
		next, err := nextCronTime(expr, time.Now())
		if err != nil {
			logger.Warn("scheduler: invalid cron expression '%s': %v", expr, err)
			return
		}
		d := time.Until(next)
		logger.Debug("scheduler: next backup at %s (in %s)", next.Format(time.RFC3339), d.Round(time.Second))
		timer = time.NewTimer(d)
		timerCh = timer.C
	}

	// load initial schedule from settings
	expr, _ := db.GetSetting(m.db, "backup_schedule")
	arm(expr)

	for {
		select {
		case <-ctx.Done():
			if timer != nil {
				timer.Stop()
			}
			logger.Debug("scheduler: stopped")
			return

		case newExpr := <-m.schedulerCh:
			arm(newExpr)

		case <-timerCh:
			// run backups then re-arm for the next occurrence
			m.runScheduledBackups(ctx)
			expr, _ = db.GetSetting(m.db, "backup_schedule")
			arm(expr)
		}
	}
}

// runScheduledBackups fires a concurrent backup for every site that has a
// repo with at least one destination enabled
func (m *Manager) runScheduledBackups(ctx context.Context) {
	logger.Debug("scheduler: starting backup run")

	sites, err := db.GetAllSites(m.db)
	if err != nil {
		logger.Error("scheduler: list sites: %v", err)
		return
	}

	var wg sync.WaitGroup
	for _, site := range sites {
		site := site
		repo, err := db.GetBackupRepo(m.db, site.ID)
		if err != nil || repo == nil {
			continue
		}
		if !repo.LocalEnabled && !repo.S3Enabled {
			continue
		}
		wg.Add(1)
		go func() {
			defer wg.Done()
			bCtx, cancel := context.WithTimeout(ctx, 2*time.Hour)
			defer cancel()
			if _, err := m.Backup(bCtx, site, "scheduled"); err != nil {
				logger.Error("scheduler: backup failed for site %s: %v", site.Name, err)
				_ = db.SetBackupError(m.db, site.ID, err.Error())
			} else {
				logger.Debug("scheduler: backup complete for site %s", site.Name)
				_ = db.ClearBackupError(m.db, site.ID)
			}
		}()
	}

	wg.Wait()
	logger.Debug("scheduler: backup run complete")
}

// -- cron parser -------------------------------------------------------------

// nextCronTime returns the next time after 'from' that satisfies the 5-field
// cron expression (minute hour dom month dow).
// Supported field syntax: * | N | */N | N-M | N,M,...
func nextCronTime(expr string, from time.Time) (time.Time, error) {
	fields := strings.Fields(expr)
	if len(fields) != 5 {
		return time.Time{}, fmt.Errorf("expected 5 fields, got %d", len(fields))
	}

	matchMinute, err := parseCronField(fields[0], 0, 59)
	if err != nil {
		return time.Time{}, fmt.Errorf("minute: %w", err)
	}
	matchHour, err := parseCronField(fields[1], 0, 23)
	if err != nil {
		return time.Time{}, fmt.Errorf("hour: %w", err)
	}
	matchDOM, err := parseCronField(fields[2], 1, 31)
	if err != nil {
		return time.Time{}, fmt.Errorf("dom: %w", err)
	}
	matchMonth, err := parseCronField(fields[3], 1, 12)
	if err != nil {
		return time.Time{}, fmt.Errorf("month: %w", err)
	}
	matchDOW, err := parseCronField(fields[4], 0, 6)
	if err != nil {
		return time.Time{}, fmt.Errorf("dow: %w", err)
	}

	// start one minute after 'from' so the current minute is never returned
	t := from.Truncate(time.Minute).Add(time.Minute)
	limit := t.Add(366 * 24 * time.Hour)

	for t.Before(limit) {
		if !matchMonth[int(t.Month())] {
			t = time.Date(t.Year(), t.Month()+1, 1, 0, 0, 0, 0, t.Location())
			continue
		}
		if !matchDOM[t.Day()] || !matchDOW[int(t.Weekday())] {
			t = time.Date(t.Year(), t.Month(), t.Day()+1, 0, 0, 0, 0, t.Location())
			continue
		}
		if !matchHour[t.Hour()] {
			t = time.Date(t.Year(), t.Month(), t.Day(), t.Hour()+1, 0, 0, 0, t.Location())
			continue
		}
		if !matchMinute[t.Minute()] {
			t = t.Add(time.Minute)
			continue
		}
		return t, nil
	}

	return time.Time{}, fmt.Errorf("no matching time within 366 days")
}

// parseCronField parses one cron field and returns the set of matching integers
func parseCronField(field string, min, max int) (map[int]bool, error) {
	result := make(map[int]bool)

	// comma-separated list — recurse on each part
	if strings.Contains(field, ",") {
		for _, part := range strings.Split(field, ",") {
			sub, err := parseCronField(strings.TrimSpace(part), min, max)
			if err != nil {
				return nil, err
			}
			for v := range sub {
				result[v] = true
			}
		}
		return result, nil
	}

	// wildcard
	if field == "*" {
		for i := min; i <= max; i++ {
			result[i] = true
		}
		return result, nil
	}

	// step: */N or base/N
	if strings.Contains(field, "/") {
		parts := strings.SplitN(field, "/", 2)
		step, err := strconv.Atoi(parts[1])
		if err != nil || step <= 0 {
			return nil, fmt.Errorf("invalid step '%s'", parts[1])
		}
		start := min
		if parts[0] != "*" {
			if start, err = strconv.Atoi(parts[0]); err != nil {
				return nil, fmt.Errorf("invalid step base '%s'", parts[0])
			}
		}
		for i := start; i <= max; i += step {
			result[i] = true
		}
		return result, nil
	}

	// range: N-M
	if strings.Contains(field, "-") {
		parts := strings.SplitN(field, "-", 2)
		lo, err1 := strconv.Atoi(parts[0])
		hi, err2 := strconv.Atoi(parts[1])
		if err1 != nil || err2 != nil || lo > hi {
			return nil, fmt.Errorf("invalid range '%s'", field)
		}
		for i := lo; i <= hi; i++ {
			result[i] = true
		}
		return result, nil
	}

	// single value
	v, err := strconv.Atoi(field)
	if err != nil || v < min || v > max {
		return nil, fmt.Errorf("invalid value '%s' (must be %d-%d)", field, min, max)
	}
	result[v] = true
	return result, nil
}

// -- .env reader -------------------------------------------------------------

// readEnvValue reads a KEY=VALUE .env file and returns the value for the given key
func readEnvValue(path, key string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	prefix := key + "="
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimRight(line, "\r")
		if strings.HasPrefix(line, prefix) {
			return strings.TrimPrefix(line, prefix), nil
		}
	}
	return "", fmt.Errorf("key %q not found in %s", key, path)
}

// EnsureRepo is the exported wrapper used by the HTTP handlers to initialise
// a site's repo record without triggering a full backup
func (m *Manager) EnsureRepo(ctx context.Context, site *models.Site) (*models.BackupRepo, error) {
	return m.ensureRepo(ctx, site)
}

// ImportDirFor returns the SFTP import drop directory path for a site
func (m *Manager) ImportDirFor(siteName string) string {
	return m.importDir(siteName)
}

// DeleteSnapshot removes the restic snapshots for a backup from all configured
// repos. The DB record deletion is handled by the calling handler.
func (m *Manager) DeleteSnapshot(ctx context.Context, site *models.Site, b *models.Backup) error {
	repo, err := db.GetBackupRepo(m.db, site.ID)
	if err != nil || repo == nil {
		return nil
	}

	s3, err := m.loadS3Config()
	if err != nil {
		return err
	}

	// forget by tag across both repos — restic forget --tag removes all
	// snapshots carrying that tag, which covers both the file and DB snapshots
	forget := func(repoPath string, env []string) error {
		// clear any stale locks before attempting forget
		unlockCmd := exec.CommandContext(ctx, resticBin, "-r", repoPath, "unlock")
		unlockCmd.Env = env
		_ = unlockCmd.Run() // best-effort, ignore errors

		// list snapshots matching the tag to get their IDs
		listCmd := exec.CommandContext(ctx, resticBin,
			"-r", repoPath, "snapshots", "--tag", b.SnapshotID, "--json",
		)
		listCmd.Env = env
		out, err := listCmd.Output()
		if err != nil {
			return fmt.Errorf("restic snapshots: %w", err)
		}

		var snaps []struct {
			ID string `json:"id"`
		}
		if err := json.Unmarshal(out, &snaps); err != nil || len(snaps) == 0 {
			logger.Debug("DeleteSnapshot: no snapshots found for tag %s in %s", b.SnapshotID, repoPath)
			return nil
		}

		// forget each snapshot by ID, then prune
		ids := make([]string, len(snaps))
		for i, s := range snaps {
			ids[i] = s.ID
		}
		args := append([]string{"-r", repoPath, "forget", "--prune"}, ids...)
		cmd := exec.CommandContext(ctx, resticBin, args...)
		cmd.Env = env
		if out, err := cmd.CombinedOutput(); err != nil {
			logger.Error("DeleteSnapshot: forget %s: %v — %s", repoPath, err, string(out))
			return fmt.Errorf("restic forget: %w", err)
		}
		return nil
	}

	if repo.LocalEnabled {
		if err := forget(repo.LocalPath, resticEnv(repo.RepoPassword, nil)); err != nil {
			return err
		}
	}
	if repo.S3Enabled && s3 != nil {
		s3Repo := s3RepoURL(s3.endpoint, s3.bucket, site.Name)
		if err := forget(s3Repo, resticEnv(repo.RepoPassword, s3)); err != nil {
			return err
		}
	}

	logger.Debug("DeleteSnapshot: removed snapshots for tag %s", b.SnapshotID)
	return nil
}

// Export streams a complete site backup as a gzip-compressed tar archive to w.
// The archive contains the full file tree from the files snapshot plus the
// database dump extracted from the DB snapshot, giving the caller a single
// self-contained archive restorable without restic.
func (m *Manager) Export(ctx context.Context, site *models.Site, backup *models.Backup, w io.Writer) error {
	repo, err := db.GetBackupRepo(m.db, site.ID)
	if err != nil || repo == nil {
		return fmt.Errorf("export: no repo configured for site %s", site.Name)
	}

	s3, err := m.loadS3Config()
	if err != nil {
		return err
	}

	// resolve which repo to export from based on the backup type
	var repoPath string
	var env []string
	switch backup.BackupType {
	case models.BackupTypeLocal:
		repoPath = repo.LocalPath
		env = resticEnv(repo.RepoPassword, nil)
	case models.BackupTypeS3:
		if s3 == nil {
			return fmt.Errorf("export: S3 not configured")
		}
		repoPath = s3RepoURL(s3.endpoint, s3.bucket, site.Name)
		env = resticEnv(repo.RepoPassword, s3)
	default:
		return fmt.Errorf("export: unknown backup type %d", backup.BackupType)
	}

	// find the file snapshot ID up front so we fail fast before writing output
	fileSnapID, err := m.findSnapshot(ctx, repoPath, env, backup.SnapshotID, "files")
	if err != nil {
		return fmt.Errorf("export: find file snapshot: %w", err)
	}

	logger.Debug("Export: fileSnapID=%q repoPath=%q", fileSnapID, repoPath)

	// restore the file snapshot to a temp directory — avoids relying on
	// restic's --archive tar flag which is not available in all versions
	tmpDir, err := os.MkdirTemp("", "podnest-export-*")
	if err != nil {
		return fmt.Errorf("export: create temp dir: %w", err)
	}
	defer os.RemoveAll(tmpDir)

	restoreCmd := exec.CommandContext(ctx, resticBin,
		"-r", repoPath, "restore", fileSnapID,
		"--target", tmpDir,
		"--exclude", "*/nginx/cache/*",
	)
	restoreCmd.Env = env

	var restoreStderr bytes.Buffer
	restoreCmd.Stderr = &restoreStderr

	if err := restoreCmd.Run(); err != nil {
		return fmt.Errorf("export: restic restore: %w — %s", err, restoreStderr.String())
	}

	// restic restores to tmpDir + original absolute path, e.g.
	// tmpDir/home/sites/sites/testsite/html/...
	siteRestoreDir := filepath.Join(tmpDir, m.appPath, "sites", site.Name)

	// wrap the response writer in gzip then tar
	gz := gzip.NewWriter(w)
	tw := tar.NewWriter(gz)

	// walk the restored site directory and emit each entry into the tar stream
	err = filepath.Walk(siteRestoreDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		// get the path relative to the site root for clean archive entries
		rel, err := filepath.Rel(siteRestoreDir, path)
		if err != nil {
			return fmt.Errorf("export: rel path: %w", err)
		}

		// build the tar header from the file's metadata
		hdr, err := tar.FileInfoHeader(info, "")
		if err != nil {
			return fmt.Errorf("export: tar header for %s: %w", rel, err)
		}
		hdr.Name = rel

		if err := tw.WriteHeader(hdr); err != nil {
			return fmt.Errorf("export: write header %s: %w", rel, err)
		}

		// copy regular file contents into the tar stream
		if info.Mode().IsRegular() {
			f, err := os.Open(path)
			if err != nil {
				return fmt.Errorf("export: open %s: %w", rel, err)
			}
			defer f.Close()
			if _, err := io.Copy(tw, f); err != nil {
				return fmt.Errorf("export: write %s: %w", rel, err)
			}
		}

		return nil
	})
	if err != nil {
		return fmt.Errorf("export: walk restore dir: %w", err)
	}

	// -- database dump -------------------------------------------------------

	// only sites with a MariaDB container have a DB snapshot
	if modules.TypeModule(site.SiteType).HasDatabase() {
		dbSnapID, err := m.findSnapshot(ctx, repoPath, env, backup.SnapshotID, "db")
		if err != nil {
			return fmt.Errorf("export: find db snapshot: %w", err)
		}

		// buffer the SQL so we know the byte size before writing the tar header
		dbCmd := exec.CommandContext(ctx, resticBin,
			"-r", repoPath, "dump", dbSnapID, "db_dump.sql",
		)
		dbCmd.Env = env

		var dbStderr bytes.Buffer
		dbCmd.Stderr = &dbStderr

		sqlData, err := dbCmd.Output()
		if err != nil {
			return fmt.Errorf("export: restic dump db: %w — %s", err, dbStderr.String())
		}

		// write db_dump.sql as a top-level entry in the archive
		if err := tw.WriteHeader(&tar.Header{
			Name:    "db_dump.sql",
			Size:    int64(len(sqlData)),
			Mode:    0644,
			ModTime: backup.Created,
		}); err != nil {
			return fmt.Errorf("export: write db header: %w", err)
		}
		if _, err := tw.Write(sqlData); err != nil {
			return fmt.Errorf("export: write db entry: %w", err)
		}
	}

	// write manifest.json with the site's domains for use during import restore
	if len(backup.Domains) > 0 {
		manifestData, err := json.Marshal(map[string]any{
			"domains": backup.Domains,
		})
		if err == nil {
			if err := tw.WriteHeader(&tar.Header{
				Name:    "manifest.json",
				Size:    int64(len(manifestData)),
				Mode:    0644,
				ModTime: backup.Created,
			}); err != nil {
				return fmt.Errorf("export: write manifest header: %w", err)
			}
			if _, err := tw.Write(manifestData); err != nil {
				return fmt.Errorf("export: write manifest: %w", err)
			}
		}
	}

	// flush tar and gzip writers to ensure all data reaches the response writer
	if err := tw.Close(); err != nil {
		return fmt.Errorf("export: close tar: %w", err)
	}
	if err := gz.Close(); err != nil {
		return fmt.Errorf("export: close gzip: %w", err)
	}

	logger.Debug("Export: completed archive for site %s backup %d", site.Name, backup.ID)
	return nil
}

// CreateFinalBackup creates a complete tar.gz archive of the site immediately
// before deletion. If S3 is configured the archive is uploaded directly;
// otherwise the raw bytes are returned for the caller to stream to the browser.
// Returns a human-readable destination label and the archive bytes when S3 is
// not configured (nil bytes when uploaded to S3).
func (m *Manager) CreateFinalBackup(ctx context.Context, site *models.Site) (dest string, archive []byte, err error) {
	now := time.Now().UTC()
	filename := fmt.Sprintf("%s_final_%s.tar.gz", site.Name, now.Format("20060102-150405"))

	s3, err := m.loadS3Config()
	if err != nil {
		return "", nil, fmt.Errorf("CreateFinalBackup: load s3 config: %w", err)
	}

	repo, err := m.ensureRepo(ctx, site)
	if err != nil {
		return "", nil, fmt.Errorf("CreateFinalBackup: ensure repo: %w", err)
	}

	tagBytes := make([]byte, 8)
	if _, err := rand.Read(tagBytes); err != nil {
		return "", nil, fmt.Errorf("CreateFinalBackup: generate tag: %w", err)
	}
	tag := "podnest-final-" + hex.EncodeToString(tagBytes)

	siteDir := filepath.Join(m.appPath, "sites", site.Name)
	includePaths := []string{
		filepath.Join(siteDir, "html"),
		filepath.Join(siteDir, "nginx"),
		filepath.Join(siteDir, "php-fpm"),
		filepath.Join(siteDir, "redis"),
		filepath.Join(siteDir, ".env"),
	}
	excludePaths := []string{
		filepath.Join(siteDir, "nginx", "cache"),
		filepath.Join(siteDir, "db"),
	}

	// force S3 when globally configured, regardless of per-site repo settings
	var repoPath string
	var repoEnv []string
	if s3 != nil {
		repoPath = s3RepoURL(s3.endpoint, s3.bucket, site.Name)
		repoEnv = resticEnv(repo.RepoPassword, s3)
		if err := initRepo(ctx, repoPath, repoEnv); err != nil {
			return "", nil, fmt.Errorf("CreateFinalBackup: init s3 repo: %w", err)
		}
	} else {
		// fall back to local repo so Export has a snapshot to work from
		repoPath = repo.LocalPath
		repoEnv = resticEnv(repo.RepoPassword, nil)
		if err := os.MkdirAll(repoPath, 0750); err != nil {
			return "", nil, fmt.Errorf("CreateFinalBackup: create local repo dir: %w", err)
		}
		if err := initRepo(ctx, repoPath, repoEnv); err != nil {
			return "", nil, fmt.Errorf("CreateFinalBackup: init local repo: %w", err)
		}
	}

	if _, err := m.backupFiles(ctx, repoPath, repoEnv, includePaths, excludePaths, tag); err != nil {
		return "", nil, fmt.Errorf("CreateFinalBackup: backup files: %w", err)
	}
	if err := m.backupDB(ctx, site, repoPath, repoEnv, tag, siteDir); err != nil {
		return "", nil, fmt.Errorf("CreateFinalBackup: backup db: %w", err)
	}

	// fetch the site's domains to store with the backup record
	siteDomains, err := db.GetDomainsBySite(m.db, site.ID)
	if err != nil {
		logger.Warn("CreateFinalBackup: failed to fetch domains for site %d: %v", site.ID, err)
	}
	var domainList []string
	for _, d := range siteDomains {
		domainList = append(domainList, d.Domain)
	}

	// record in DB so Export can find the snapshot
	b := &models.Backup{
		SiteID:     site.ID,
		SnapshotID: tag,
		Label:      "final",
		BackupType: func() int {
			if s3 != nil {
				return models.BackupTypeS3
			}
			return models.BackupTypeLocal
		}(),
		Domains: domainList,
	}
	bid, err := db.CreateBackup(m.db, b)
	if err != nil {
		return "", nil, fmt.Errorf("CreateFinalBackup: record backup: %w", err)
	}

	stored, err := db.GetBackup(m.db, bid)
	if err != nil || stored == nil {
		return "", nil, fmt.Errorf("CreateFinalBackup: get backup record: %w", err)
	}

	var buf bytes.Buffer
	if err := m.Export(ctx, site, stored, &buf); err != nil {
		return "", nil, fmt.Errorf("CreateFinalBackup: export: %w", err)
	}

	if s3 != nil {
		key := site.Name + "/" + filename
		if err := s3PutObject(ctx, s3, key, buf.Bytes()); err != nil {
			return "", nil, fmt.Errorf("CreateFinalBackup: s3 upload: %w", err)
		}
		logger.Debug("CreateFinalBackup: uploaded %s to S3 bucket %s", key, s3.bucket)
		return "s3:" + s3.bucket + "/" + key, nil, nil
	}

	logger.Debug("CreateFinalBackup: returning archive %s for browser download", filename)
	return "browser:" + filename, buf.Bytes(), nil
}

// s3PutObject uploads data to an S3-compatible bucket using AWS Signature V4.
// Uses only stdlib — no AWS SDK.
func s3PutObject(ctx context.Context, s3 *s3Config, key string, data []byte) error {
	ep := strings.TrimRight(s3.endpoint, "/")
	rawURL := fmt.Sprintf("%s/%s/%s", ep, s3.bucket, key)

	now := time.Now().UTC()
	dateStamp := now.Format("20060102")
	amzDate := now.Format("20060102T150405Z")

	bodyHash := fmt.Sprintf("%x", sha256.Sum256(data))

	// canonical headers (must be sorted)
	canonHeaders := map[string]string{
		"host":                 strings.TrimPrefix(strings.TrimPrefix(ep, "https://"), "http://"),
		"x-amz-content-sha256": bodyHash,
		"x-amz-date":           amzDate,
	}
	headerKeys := make([]string, 0, len(canonHeaders))
	for k := range canonHeaders {
		headerKeys = append(headerKeys, k)
	}
	sort.Strings(headerKeys)

	var canonHeaderStr, signedHeaderStr strings.Builder
	for _, k := range headerKeys {
		canonHeaderStr.WriteString(k + ":" + canonHeaders[k] + "\n")
		if signedHeaderStr.Len() > 0 {
			signedHeaderStr.WriteByte(';')
		}
		signedHeaderStr.WriteString(k)
	}

	parsedURL, err := url.Parse(rawURL)
	if err != nil {
		return fmt.Errorf("s3PutObject: parse url: %w", err)
	}

	canonRequest := strings.Join([]string{
		"PUT",
		parsedURL.EscapedPath(),
		"", // no query string
		canonHeaderStr.String(),
		signedHeaderStr.String(),
		bodyHash,
	}, "\n")

	credScope := strings.Join([]string{dateStamp, s3.region, "s3", "aws4_request"}, "/")
	strToSign := strings.Join([]string{
		"AWS4-HMAC-SHA256",
		amzDate,
		credScope,
		fmt.Sprintf("%x", sha256.Sum256([]byte(canonRequest))),
	}, "\n")

	// derive the signing key
	sign := func(key, data []byte) []byte {
		h := hmac.New(sha256.New, key)
		h.Write(data)
		return h.Sum(nil)
	}
	signingKey := sign(
		sign(
			sign(
				sign([]byte("AWS4"+s3.secretKey), []byte(dateStamp)),
				[]byte(s3.region),
			),
			[]byte("s3"),
		),
		[]byte("aws4_request"),
	)
	signature := fmt.Sprintf("%x", hmac.New(sha256.New, signingKey).Sum([]byte(strToSign)))[len(strToSign)*2:]

	// rebuild signature correctly
	mac := hmac.New(sha256.New, signingKey)
	mac.Write([]byte(strToSign))
	signature = hex.EncodeToString(mac.Sum(nil))

	authHeader := fmt.Sprintf(
		"AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s",
		s3.accessKey, credScope, signedHeaderStr.String(), signature,
	)

	req, err := http.NewRequestWithContext(ctx, http.MethodPut, rawURL, bytes.NewReader(data))
	if err != nil {
		return fmt.Errorf("s3PutObject: new request: %w", err)
	}
	req.Header.Set("Authorization", authHeader)
	req.Header.Set("X-Amz-Date", amzDate)
	req.Header.Set("X-Amz-Content-Sha256", bodyHash)
	req.Header.Set("Content-Type", "application/gzip")
	req.ContentLength = int64(len(data))

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return fmt.Errorf("s3PutObject: do: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusNoContent && resp.StatusCode != http.StatusCreated {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("s3PutObject: unexpected status %d: %s", resp.StatusCode, string(body))
	}
	return nil
}

// fixPostRestorePerms reapplies the correct ownership and permissions to the
// site directory after a file restore, matching what scaffoldSiteDir sets up
func (m *Manager) fixPostRestorePerms(siteDir string, siteID int64) {
	cred, err := db.GetSFTPCredBySite(m.db, siteID)
	if err != nil || cred == nil {
		logger.Warn("fixPostRestorePerms: could not get sftp cred for site %d: %v", siteID, err)
		return
	}
	uid := cred.UID

	// site root — must be root:root for sshd chroot
	os.Chown(siteDir, 0, 0)
	os.Chmod(siteDir, 0755)

	// html — setgid + group-writable, siteUID owned
	os.Chown(siteDir+"/html", uid, uid)
	os.Chmod(siteDir+"/html", 0755)

	// php-fpm, redis — siteUID owned
	for _, d := range []string{"php-fpm", "redis"} {
		os.Chown(siteDir+"/"+d, uid, uid)
	}

	// nginx dir — siteUID owned
	os.Chown(siteDir+"/nginx", uid, uid)

	// nginx/logs — nginx uid (101)
	os.Chown(siteDir+"/nginx/logs", 101, 101)
	os.Chmod(siteDir+"/nginx/logs", 0750)

	// db — mysql uid (999) inside the MariaDB container
	os.Chown(siteDir+"/db", 999, 999)

	logger.Debug("fixPostRestorePerms: permissions restored for %s", siteDir)
}

// -- import restore ----------------------------------------------------------

// importDir returns the SFTP import drop directory for a site
func (m *Manager) importDir(siteName string) string {
	return filepath.Join(m.appPath, "sites", siteName, "backups", "import")
}

// ListImportFiles returns the filenames of any importable archives in the
// site's SFTP import directory (.tar.gz, .tar.xz, .zip)
func (m *Manager) ListImportFiles(siteName string) ([]string, error) {
	dir := m.importDir(siteName)
	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return []string{}, nil
		}
		return nil, fmt.Errorf("ListImportFiles: %w", err)
	}

	var files []string
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		n := e.Name()
		// only surface recognised archive formats
		if strings.HasSuffix(n, ".tar.gz") ||
			strings.HasSuffix(n, ".tar.xz") ||
			strings.HasSuffix(n, ".zip") {
			files = append(files, n)
		}
	}
	return files, nil
}

// ImportRestore extracts the archive at archivePath and restores it onto
// targetSite. On success the archive file is deleted. The site is placed in
// maintenance mode for the duration of the restore.
func (m *Manager) ImportRestore(ctx context.Context, targetSite *models.Site, archivePath string) error {
	m.restoring.Store(targetSite.ID, true)
	defer m.restoring.Delete(targetSite.ID)

	siteDir := filepath.Join(m.appPath, "sites", targetSite.Name)

	// enable maintenance mode before touching any site data
	if err := m.enableMaintenance(ctx, targetSite, siteDir); err != nil {
		return fmt.Errorf("ImportRestore: enable maintenance: %w", err)
	}
	defer func() {
		if err := m.disableMaintenance(ctx, targetSite, siteDir); err != nil {
			logger.Error("ImportRestore: disable maintenance for site %s: %v", targetSite.Name, err)
		}
	}()

	// extract the archive to a temp directory
	tmpDir, err := os.MkdirTemp("", "podnest-import-*")
	if err != nil {
		return fmt.Errorf("ImportRestore: create temp dir: %w", err)
	}
	defer os.RemoveAll(tmpDir)

	if err := extractArchive(archivePath, tmpDir); err != nil {
		return fmt.Errorf("ImportRestore: extract: %w", err)
	}

	// copy extracted files into the site directory, excluding .env and db_dump.sql
	if err := importFiles(tmpDir, siteDir); err != nil {
		return fmt.Errorf("ImportRestore: import files: %w", err)
	}

	// reapply correct ownership after the file copy
	m.fixPostRestorePerms(siteDir, targetSite.ID)

	// restore the database if a dump is present and the site type has a database
	dbDump := filepath.Join(tmpDir, "db_dump.sql")
	if _, err := os.Stat(dbDump); err == nil {
		if modules.TypeModule(targetSite.SiteType).HasDatabase() {
			if err := m.importDB(ctx, targetSite, dbDump, siteDir); err != nil {
				return fmt.Errorf("ImportRestore: import db: %w", err)
			}
		}
	}

	// read the manifest to get source domains for search-replace
	sourceDomains := readImportManifest(tmpDir)

	// run search-replace for WordPress sites if we have a source domain to replace
	if targetSite.SiteType == models.SiteTypeWordPress && len(sourceDomains) > 0 {
		// fetch the target site's primary domain
		targetDomains, err := db.GetDomainsBySite(m.db, targetSite.ID)
		if err != nil || len(targetDomains) == 0 {
			logger.Warn("ImportRestore: could not fetch target domains for site %s: %v", targetSite.Name, err)
		} else {
			fromDomain := sourceDomains[0]
			toDomain := targetDomains[0].Domain
			if fromDomain != toDomain {
				if err := m.wpSearchReplace(ctx, targetSite, fromDomain, toDomain); err != nil {
					logger.Error("ImportRestore: search-replace failed for site %s: %v", targetSite.Name, err)
				}
			}
		}
	}

	// delete the source archive now that the restore succeeded
	if err := os.Remove(archivePath); err != nil {
		logger.Warn("ImportRestore: remove archive %s: %v", archivePath, err)
	}

	logger.Debug("ImportRestore: completed for site %s from %s", targetSite.Name, filepath.Base(archivePath))
	return nil
}

// extractArchive dispatches to the correct extractor based on file extension
func extractArchive(src, destDir string) error {
	switch {
	case strings.HasSuffix(src, ".tar.gz"):
		return extractTarGz(src, destDir)
	case strings.HasSuffix(src, ".tar.xz"):
		return extractTarXz(src, destDir)
	case strings.HasSuffix(src, ".zip"):
		return extractZip(src, destDir)
	default:
		return fmt.Errorf("extractArchive: unsupported format: %s", filepath.Base(src))
	}
}

// extractTarGz extracts a .tar.gz archive into destDir
func extractTarGz(src, destDir string) error {
	f, err := os.Open(src)
	if err != nil {
		return err
	}
	defer f.Close()

	gr, err := gzip.NewReader(f)
	if err != nil {
		return fmt.Errorf("extractTarGz: gzip reader: %w", err)
	}
	defer gr.Close()

	return extractTar(tar.NewReader(gr), destDir)
}

// extractTarXz extracts a .tar.xz archive into destDir via the xz binary
func extractTarXz(src, destDir string) error {
	// decompress via xz CLI, pipe stdout into the tar reader
	xzCmd := exec.Command("xz", "-d", "-c", src)
	pr, err := xzCmd.StdoutPipe()
	if err != nil {
		return fmt.Errorf("extractTarXz: stdout pipe: %w", err)
	}
	if err := xzCmd.Start(); err != nil {
		return fmt.Errorf("extractTarXz: start xz: %w", err)
	}

	tarErr := extractTar(tar.NewReader(pr), destDir)
	waitErr := xzCmd.Wait()

	if tarErr != nil {
		return tarErr
	}
	return waitErr
}

// extractTar reads all entries from a tar.Reader into destDir, guarding
// against path traversal attacks
func extractTar(tr *tar.Reader, destDir string) error {
	for {
		hdr, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return fmt.Errorf("extractTar: next: %w", err)
		}

		// guard against path traversal
		target := filepath.Join(destDir, filepath.Clean("/"+hdr.Name))
		if !strings.HasPrefix(target, destDir+string(os.PathSeparator)) && target != destDir {
			logger.Warn("extractTar: skipping unsafe path %s", hdr.Name)
			continue
		}

		switch hdr.Typeflag {
		case tar.TypeDir:
			if err := os.MkdirAll(target, 0755); err != nil {
				return fmt.Errorf("extractTar: mkdir %s: %w", hdr.Name, err)
			}
		case tar.TypeReg:
			if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil {
				return fmt.Errorf("extractTar: mkdir parent %s: %w", hdr.Name, err)
			}
			f, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, hdr.FileInfo().Mode())
			if err != nil {
				return fmt.Errorf("extractTar: create %s: %w", hdr.Name, err)
			}
			if _, err := io.Copy(f, tr); err != nil {
				f.Close()
				return fmt.Errorf("extractTar: write %s: %w", hdr.Name, err)
			}
			f.Close()
		}
	}
	return nil
}

// extractZip extracts a .zip archive into destDir, guarding against path traversal
func extractZip(src, destDir string) error {
	// stat the file to get its size for zip.OpenReader
	fi, err := os.Stat(src)
	if err != nil {
		return fmt.Errorf("extractZip: stat: %w", err)
	}

	f, err := os.Open(src)
	if err != nil {
		return fmt.Errorf("extractZip: open: %w", err)
	}
	defer f.Close()

	zr, err := zip.NewReader(f, fi.Size())
	if err != nil {
		return fmt.Errorf("extractZip: reader: %w", err)
	}

	for _, zf := range zr.File {
		target := filepath.Join(destDir, filepath.Clean("/"+zf.Name))
		if !strings.HasPrefix(target, destDir+string(os.PathSeparator)) && target != destDir {
			logger.Warn("extractZip: skipping unsafe path %s", zf.Name)
			continue
		}

		if zf.FileInfo().IsDir() {
			os.MkdirAll(target, 0755)
			continue
		}

		if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil {
			return fmt.Errorf("extractZip: mkdir %s: %w", zf.Name, err)
		}

		rc, err := zf.Open()
		if err != nil {
			return fmt.Errorf("extractZip: open entry %s: %w", zf.Name, err)
		}
		out, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, zf.Mode())
		if err != nil {
			rc.Close()
			return fmt.Errorf("extractZip: create %s: %w", zf.Name, err)
		}
		_, copyErr := io.Copy(out, rc)
		rc.Close()
		out.Close()
		if copyErr != nil {
			return fmt.Errorf("extractZip: write %s: %w", zf.Name, copyErr)
		}
	}
	return nil
}

// importFiles copies the extracted archive contents into siteDir, skipping
// .env (target site credentials are preserved) and db_dump.sql (handled separately)
func importFiles(srcDir, siteDir string) error {
	return filepath.Walk(srcDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		rel, err := filepath.Rel(srcDir, path)
		if err != nil {
			return fmt.Errorf("importFiles: rel path: %w", err)
		}

		// skip the root itself
		if rel == "." {
			return nil
		}

		// never overwrite the target site's credentials or import the raw dump
		if rel == ".env" || rel == "db_dump.sql" || rel == "manifest.json" ||
			rel == "html/wp-config.php" || rel == "html/web.config" || rel == "html/.env" {
			return nil
		}

		dest := filepath.Join(siteDir, rel)

		if info.IsDir() {
			return os.MkdirAll(dest, 0755)
		}

		if err := os.MkdirAll(filepath.Dir(dest), 0755); err != nil {
			return fmt.Errorf("importFiles: mkdir %s: %w", rel, err)
		}
		src, err := os.Open(path)
		if err != nil {
			return fmt.Errorf("importFiles: open %s: %w", rel, err)
		}
		defer src.Close()

		dst, err := os.OpenFile(dest, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, info.Mode())
		if err != nil {
			return fmt.Errorf("importFiles: create %s: %w", rel, err)
		}
		defer dst.Close()

		if _, err := io.Copy(dst, src); err != nil {
			return fmt.Errorf("importFiles: copy %s: %w", rel, err)
		}
		return nil
	})
}

// importDB pipes db_dump.sql into the target site's MariaDB container,
// rewriting USE / CREATE DATABASE statements to match the target site name
func (m *Manager) importDB(ctx context.Context, site *models.Site, dumpPath, siteDir string) error {
	rootPass, err := readEnvValue(filepath.Join(siteDir, ".env"), "DB_ROOT_PASS")
	if err != nil {
		return fmt.Errorf("importDB: DB_ROOT_PASS: %w", err)
	}
	dbName, err := readEnvValue(filepath.Join(siteDir, ".env"), "DB_NAME")
	if err != nil {
		return fmt.Errorf("importDB: DB_NAME: %w", err)
	}

	// rewrite the dump to a temp file with corrected db references
	rewritten, err := os.CreateTemp("", "podnest-import-db-*.sql")
	if err != nil {
		return fmt.Errorf("importDB: create temp: %w", err)
	}
	defer os.Remove(rewritten.Name())

	if err := rewriteDBDump(dumpPath, rewritten, dbName); err != nil {
		rewritten.Close()
		return fmt.Errorf("importDB: rewrite: %w", err)
	}
	rewritten.Close()

	// get the databse container name
	dbContainer := podman.ContainerName(site.Name, "db")

	// ensure no stale directory exists at the import path inside the container
	cleanCmd := exec.CommandContext(ctx, "podman",
		"exec", dbContainer, "rm", "-rf", "/tmp/podnest-import.sql",
	)

	// copy the rewritten dump into the container
	cleanCmd.Env = append(os.Environ(), "CONTAINER_HOST=unix://"+m.podmanSock)
	_ = cleanCmd.Run()
	cpCmd := exec.CommandContext(ctx, "podman",
		"cp", rewritten.Name(), dbContainer+":/tmp/podnest-import.sql",
	)
	cpCmd.Env = append(os.Environ(), "CONTAINER_HOST=unix://"+m.podmanSock)
	if out, err := cpCmd.CombinedOutput(); err != nil {
		return fmt.Errorf("importDB: podman cp: %w — %s", err, string(out))
	}

	// run the import inside the container
	mysqlCmd := exec.CommandContext(ctx, "podman",
		"exec", dbContainer,
		"sh", "-c",
		fmt.Sprintf("mariadb -uroot -p%s %s < /tmp/podnest-import.sql && rm /tmp/podnest-import.sql", rootPass, dbName),
	)
	mysqlCmd.Env = append(os.Environ(), "CONTAINER_HOST=unix://"+m.podmanSock)
	var mysqlStderr bytes.Buffer
	mysqlCmd.Stderr = &mysqlStderr
	if err := mysqlCmd.Run(); err != nil {
		return fmt.Errorf("importDB: mariadb: %w — %s", err, mysqlStderr.String())
	}

	logger.Debug("importDB: DB imported for site %s", site.Name)
	return nil
}

// rewriteDBDump copies src to dst line by line, replacing USE / CREATE DATABASE
// statements that reference any database name with the target database name
func rewriteDBDump(srcPath string, dst *os.File, targetDB string) error {
	f, err := os.Open(srcPath)
	if err != nil {
		return err
	}
	defer f.Close()

	// patterns to match and rewrite — case-insensitive prefix checks
	usePrefix := "use `"
	createPrefix := "create database "

	// always inject the target database selection at the top of the dump
	if _, err := fmt.Fprintf(dst, "USE `%s`;\n", targetDB); err != nil {
		return fmt.Errorf("rewriteDBDump: write USE: %w", err)
	}

	scanner := bufio.NewScanner(f)
	// increase the buffer for very long lines (e.g. large INSERT rows)
	scanner.Buffer(make([]byte, 4*1024*1024), 4*1024*1024)

	for scanner.Scan() {
		line := scanner.Text()
		lower := strings.ToLower(line)

		if strings.HasPrefix(lower, usePrefix) {
			// rewrite: USE `anything`; → USE `targetDB`;
			line = fmt.Sprintf("USE `%s`;", targetDB)
		} else if strings.HasPrefix(lower, createPrefix) {
			// rewrite: CREATE DATABASE `anything` ... → CREATE DATABASE IF NOT EXISTS `targetDB`;
			line = fmt.Sprintf("CREATE DATABASE IF NOT EXISTS `%s`;", targetDB)
		}

		if _, err := fmt.Fprintln(dst, line); err != nil {
			return fmt.Errorf("rewriteDBDump: write: %w", err)
		}
	}
	return scanner.Err()
}

// ensureWPCLI installs wp-cli into the PHP container if not already present
func (m *Manager) ensureWPCLI(ctx context.Context, containerName string) error {
	var checkResp struct {
		ID string `json:"Id"`
	}
	if err := m.podman.PostJSON(ctx,
		"/v4.0.0/libpod/containers/"+containerName+"/exec",
		map[string]any{
			"AttachStdout": true,
			"AttachStderr": true,
			"Detach":       false,
			"Cmd":          []string{"test", "-f", "/usr/local/bin/wp"},
		}, &checkResp,
	); err == nil {
		_ = m.podman.PostJSON(ctx, "/v4.0.0/libpod/exec/"+checkResp.ID+"/start",
			map[string]any{"Detach": false}, nil)
		var inspect struct {
			ExitCode int  `json:"ExitCode"`
			Running  bool `json:"Running"`
		}
		if err := m.podman.GetJSON(ctx, "/v4.0.0/libpod/exec/"+checkResp.ID+"/json", &inspect); err == nil &&
			!inspect.Running && inspect.ExitCode == 0 {
			return nil
		}
	}

	logger.Debug("ensureWPCLI: installing wp-cli in container %s", containerName)
	var installResp struct {
		ID string `json:"Id"`
	}
	if err := m.podman.PostJSON(ctx,
		"/v4.0.0/libpod/containers/"+containerName+"/exec",
		map[string]any{
			"AttachStdout": true,
			"AttachStderr": true,
			"Detach":       false,
			"Cmd": []string{"sh", "-c",
				"wget -q https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar" +
					" -O /tmp/wp.phar && chmod +x /tmp/wp.phar && mv /tmp/wp.phar /usr/local/bin/wp",
			},
		}, &installResp,
	); err != nil {
		return fmt.Errorf("ensureWPCLI: create install exec: %w", err)
	}

	if err := m.podman.PostJSON(ctx,
		"/v4.0.0/libpod/exec/"+installResp.ID+"/start",
		map[string]any{"Detach": false}, nil,
	); err != nil {
		return fmt.Errorf("ensureWPCLI: start install exec: %w", err)
	}

	logger.Debug("ensureWPCLI: wp-cli installed in %s", containerName)
	return nil
}

// wpSearchReplace runs wp search-replace inside the PHP container to rewrite
// the source domain to the target domain throughout the WordPress database
func (m *Manager) wpSearchReplace(ctx context.Context, site *models.Site, fromDomain, toDomain string) error {
	containerName := podman.ContainerName(site.Name, "php")

	if err := m.ensureWPCLI(ctx, containerName); err != nil {
		return fmt.Errorf("wpSearchReplace: %w", err)
	}

	var execResp struct {
		ID string `json:"Id"`
	}
	if err := m.podman.PostJSON(ctx,
		"/v4.0.0/libpod/containers/"+containerName+"/exec",
		map[string]any{
			"AttachStdout": true,
			"AttachStderr": true,
			"Detach":       false,
			"Cmd": []string{
				"/usr/local/bin/wp",
				"--path=/var/www/html",
				"--allow-root",
				"search-replace",
				"--all-tables",
				"--precise",
				fromDomain,
				toDomain,
			},
		}, &execResp,
	); err != nil {
		return fmt.Errorf("wpSearchReplace: create exec: %w", err)
	}

	if err := m.podman.PostJSON(ctx,
		"/v4.0.0/libpod/exec/"+execResp.ID+"/start",
		map[string]any{"Detach": false}, nil,
	); err != nil {
		return fmt.Errorf("wpSearchReplace: start exec: %w", err)
	}

	logger.Debug("wpSearchReplace: replaced %s → %s for site %s", fromDomain, toDomain, site.Name)
	return nil
}

// readImportManifest reads manifest.json from the extracted archive temp dir
// and returns the domain list, or nil if no manifest is present
func readImportManifest(tmpDir string) []string {
	data, err := os.ReadFile(filepath.Join(tmpDir, "manifest.json"))
	if err != nil {
		return nil
	}
	var m struct {
		Domains []string `json:"domains"`
	}
	if err := json.Unmarshal(data, &m); err != nil {
		return nil
	}
	return m.Domains
}
